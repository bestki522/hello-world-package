def hello_world():
    print("HELLO WORLD")

def hello_girl():
    print("HELLO LADY")
